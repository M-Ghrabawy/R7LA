(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,43216,e=>{"use strict";let t,i;var n=e.i(31067),s=e.i(71645),r=e.i(68338),o=e.i(38408),a=r,l=r;let c=new l.VQ,d=new l.cE;class f extends l.Kx{constructor(){super(),this.isLineSegmentsGeometry=!0,this.type="LineSegmentsGeometry",this.setIndex([0,2,1,2,3,1,2,4,3,4,5,3,4,6,5,6,7,5]),this.setAttribute("position",new l.ki([-1,2,0,1,2,0,-1,1,0,1,1,0,-1,0,0,1,0,0,-1,-1,0,1,-1,0],3)),this.setAttribute("uv",new l.ki([-1,2,1,2,-1,1,1,1,-1,-1,1,-1,-1,-2,1,-2],2))}applyMatrix4(e){let t=this.attributes.instanceStart,i=this.attributes.instanceEnd;return void 0!==t&&(t.applyMatrix4(e),i.applyMatrix4(e),t.needsUpdate=!0),null!==this.boundingBox&&this.computeBoundingBox(),null!==this.boundingSphere&&this.computeBoundingSphere(),this}setPositions(e){let t;e instanceof Float32Array?t=e:Array.isArray(e)&&(t=new Float32Array(e));let i=new l.hC(t,6,1);return this.setAttribute("instanceStart",new l.Zq(i,3,0)),this.setAttribute("instanceEnd",new l.Zq(i,3,3)),this.computeBoundingBox(),this.computeBoundingSphere(),this}setColors(e,t=3){let i;e instanceof Float32Array?i=e:Array.isArray(e)&&(i=new Float32Array(e));let n=new l.hC(i,2*t,1);return this.setAttribute("instanceColorStart",new l.Zq(n,t,0)),this.setAttribute("instanceColorEnd",new l.Zq(n,t,t)),this}fromWireframeGeometry(e){return this.setPositions(e.attributes.position.array),this}fromEdgesGeometry(e){return this.setPositions(e.attributes.position.array),this}fromMesh(e){return this.fromWireframeGeometry(new l.nw(e.geometry)),this}fromLineSegments(e){let t=e.geometry;return this.setPositions(t.attributes.position.array),this}computeBoundingBox(){null===this.boundingBox&&(this.boundingBox=new l.VQ);let e=this.attributes.instanceStart,t=this.attributes.instanceEnd;void 0!==e&&void 0!==t&&(this.boundingBox.setFromBufferAttribute(e),c.setFromBufferAttribute(t),this.boundingBox.union(c))}computeBoundingSphere(){null===this.boundingSphere&&(this.boundingSphere=new l.L0),null===this.boundingBox&&this.computeBoundingBox();let e=this.attributes.instanceStart,t=this.attributes.instanceEnd;if(void 0!==e&&void 0!==t){let i=this.boundingSphere.center;this.boundingBox.getCenter(i);let n=0;for(let s=0,r=e.count;s<r;s++)d.fromBufferAttribute(e,s),n=Math.max(n,i.distanceToSquared(d)),d.fromBufferAttribute(t,s),n=Math.max(n,i.distanceToSquared(d));this.boundingSphere.radius=Math.sqrt(n),isNaN(this.boundingSphere.radius)&&console.error("THREE.LineSegmentsGeometry.computeBoundingSphere(): Computed radius is NaN. The instanced position data is likely to have NaN values.",this)}}toJSON(){}applyMatrix(e){return console.warn("THREE.LineSegmentsGeometry: applyMatrix() has been renamed to applyMatrix4()."),this.applyMatrix4(e)}}var u=r,p=e.i(8560);let h=parseInt(r.Tu.replace(/\D+/g,""));class m extends u.Zg{constructor(e){super({type:"LineMaterial",uniforms:u.SP.clone(u.SP.merge([p.O.common,p.O.fog,{worldUnits:{value:1},linewidth:{value:1},resolution:{value:new u.wq(1,1)},dashOffset:{value:0},dashScale:{value:1},dashSize:{value:1},gapSize:{value:1}}])),vertexShader:`
				#include <common>
				#include <fog_pars_vertex>
				#include <logdepthbuf_pars_vertex>
				#include <clipping_planes_pars_vertex>

				uniform float linewidth;
				uniform vec2 resolution;

				attribute vec3 instanceStart;
				attribute vec3 instanceEnd;

				#ifdef USE_COLOR
					#ifdef USE_LINE_COLOR_ALPHA
						varying vec4 vLineColor;
						attribute vec4 instanceColorStart;
						attribute vec4 instanceColorEnd;
					#else
						varying vec3 vLineColor;
						attribute vec3 instanceColorStart;
						attribute vec3 instanceColorEnd;
					#endif
				#endif

				#ifdef WORLD_UNITS

					varying vec4 worldPos;
					varying vec3 worldStart;
					varying vec3 worldEnd;

					#ifdef USE_DASH

						varying vec2 vUv;

					#endif

				#else

					varying vec2 vUv;

				#endif

				#ifdef USE_DASH

					uniform float dashScale;
					attribute float instanceDistanceStart;
					attribute float instanceDistanceEnd;
					varying float vLineDistance;

				#endif

				void trimSegment( const in vec4 start, inout vec4 end ) {

					// trim end segment so it terminates between the camera plane and the near plane

					// conservative estimate of the near plane
					float a = projectionMatrix[ 2 ][ 2 ]; // 3nd entry in 3th column
					float b = projectionMatrix[ 3 ][ 2 ]; // 3nd entry in 4th column
					float nearEstimate = - 0.5 * b / a;

					float alpha = ( nearEstimate - start.z ) / ( end.z - start.z );

					end.xyz = mix( start.xyz, end.xyz, alpha );

				}

				void main() {

					#ifdef USE_COLOR

						vLineColor = ( position.y < 0.5 ) ? instanceColorStart : instanceColorEnd;

					#endif

					#ifdef USE_DASH

						vLineDistance = ( position.y < 0.5 ) ? dashScale * instanceDistanceStart : dashScale * instanceDistanceEnd;
						vUv = uv;

					#endif

					float aspect = resolution.x / resolution.y;

					// camera space
					vec4 start = modelViewMatrix * vec4( instanceStart, 1.0 );
					vec4 end = modelViewMatrix * vec4( instanceEnd, 1.0 );

					#ifdef WORLD_UNITS

						worldStart = start.xyz;
						worldEnd = end.xyz;

					#else

						vUv = uv;

					#endif

					// special case for perspective projection, and segments that terminate either in, or behind, the camera plane
					// clearly the gpu firmware has a way of addressing this issue when projecting into ndc space
					// but we need to perform ndc-space calculations in the shader, so we must address this issue directly
					// perhaps there is a more elegant solution -- WestLangley

					bool perspective = ( projectionMatrix[ 2 ][ 3 ] == - 1.0 ); // 4th entry in the 3rd column

					if ( perspective ) {

						if ( start.z < 0.0 && end.z >= 0.0 ) {

							trimSegment( start, end );

						} else if ( end.z < 0.0 && start.z >= 0.0 ) {

							trimSegment( end, start );

						}

					}

					// clip space
					vec4 clipStart = projectionMatrix * start;
					vec4 clipEnd = projectionMatrix * end;

					// ndc space
					vec3 ndcStart = clipStart.xyz / clipStart.w;
					vec3 ndcEnd = clipEnd.xyz / clipEnd.w;

					// direction
					vec2 dir = ndcEnd.xy - ndcStart.xy;

					// account for clip-space aspect ratio
					dir.x *= aspect;
					dir = normalize( dir );

					#ifdef WORLD_UNITS

						// get the offset direction as perpendicular to the view vector
						vec3 worldDir = normalize( end.xyz - start.xyz );
						vec3 offset;
						if ( position.y < 0.5 ) {

							offset = normalize( cross( start.xyz, worldDir ) );

						} else {

							offset = normalize( cross( end.xyz, worldDir ) );

						}

						// sign flip
						if ( position.x < 0.0 ) offset *= - 1.0;

						float forwardOffset = dot( worldDir, vec3( 0.0, 0.0, 1.0 ) );

						// don't extend the line if we're rendering dashes because we
						// won't be rendering the endcaps
						#ifndef USE_DASH

							// extend the line bounds to encompass  endcaps
							start.xyz += - worldDir * linewidth * 0.5;
							end.xyz += worldDir * linewidth * 0.5;

							// shift the position of the quad so it hugs the forward edge of the line
							offset.xy -= dir * forwardOffset;
							offset.z += 0.5;

						#endif

						// endcaps
						if ( position.y > 1.0 || position.y < 0.0 ) {

							offset.xy += dir * 2.0 * forwardOffset;

						}

						// adjust for linewidth
						offset *= linewidth * 0.5;

						// set the world position
						worldPos = ( position.y < 0.5 ) ? start : end;
						worldPos.xyz += offset;

						// project the worldpos
						vec4 clip = projectionMatrix * worldPos;

						// shift the depth of the projected points so the line
						// segments overlap neatly
						vec3 clipPose = ( position.y < 0.5 ) ? ndcStart : ndcEnd;
						clip.z = clipPose.z * clip.w;

					#else

						vec2 offset = vec2( dir.y, - dir.x );
						// undo aspect ratio adjustment
						dir.x /= aspect;
						offset.x /= aspect;

						// sign flip
						if ( position.x < 0.0 ) offset *= - 1.0;

						// endcaps
						if ( position.y < 0.0 ) {

							offset += - dir;

						} else if ( position.y > 1.0 ) {

							offset += dir;

						}

						// adjust for linewidth
						offset *= linewidth;

						// adjust for clip-space to screen-space conversion // maybe resolution should be based on viewport ...
						offset /= resolution.y;

						// select end
						vec4 clip = ( position.y < 0.5 ) ? clipStart : clipEnd;

						// back to clip space
						offset *= clip.w;

						clip.xy += offset;

					#endif

					gl_Position = clip;

					vec4 mvPosition = ( position.y < 0.5 ) ? start : end; // this is an approximation

					#include <logdepthbuf_vertex>
					#include <clipping_planes_vertex>
					#include <fog_vertex>

				}
			`,fragmentShader:`
				uniform vec3 diffuse;
				uniform float opacity;
				uniform float linewidth;

				#ifdef USE_DASH

					uniform float dashOffset;
					uniform float dashSize;
					uniform float gapSize;

				#endif

				varying float vLineDistance;

				#ifdef WORLD_UNITS

					varying vec4 worldPos;
					varying vec3 worldStart;
					varying vec3 worldEnd;

					#ifdef USE_DASH

						varying vec2 vUv;

					#endif

				#else

					varying vec2 vUv;

				#endif

				#include <common>
				#include <fog_pars_fragment>
				#include <logdepthbuf_pars_fragment>
				#include <clipping_planes_pars_fragment>

				#ifdef USE_COLOR
					#ifdef USE_LINE_COLOR_ALPHA
						varying vec4 vLineColor;
					#else
						varying vec3 vLineColor;
					#endif
				#endif

				vec2 closestLineToLine(vec3 p1, vec3 p2, vec3 p3, vec3 p4) {

					float mua;
					float mub;

					vec3 p13 = p1 - p3;
					vec3 p43 = p4 - p3;

					vec3 p21 = p2 - p1;

					float d1343 = dot( p13, p43 );
					float d4321 = dot( p43, p21 );
					float d1321 = dot( p13, p21 );
					float d4343 = dot( p43, p43 );
					float d2121 = dot( p21, p21 );

					float denom = d2121 * d4343 - d4321 * d4321;

					float numer = d1343 * d4321 - d1321 * d4343;

					mua = numer / denom;
					mua = clamp( mua, 0.0, 1.0 );
					mub = ( d1343 + d4321 * ( mua ) ) / d4343;
					mub = clamp( mub, 0.0, 1.0 );

					return vec2( mua, mub );

				}

				void main() {

					#include <clipping_planes_fragment>

					#ifdef USE_DASH

						if ( vUv.y < - 1.0 || vUv.y > 1.0 ) discard; // discard endcaps

						if ( mod( vLineDistance + dashOffset, dashSize + gapSize ) > dashSize ) discard; // todo - FIX

					#endif

					float alpha = opacity;

					#ifdef WORLD_UNITS

						// Find the closest points on the view ray and the line segment
						vec3 rayEnd = normalize( worldPos.xyz ) * 1e5;
						vec3 lineDir = worldEnd - worldStart;
						vec2 params = closestLineToLine( worldStart, worldEnd, vec3( 0.0, 0.0, 0.0 ), rayEnd );

						vec3 p1 = worldStart + lineDir * params.x;
						vec3 p2 = rayEnd * params.y;
						vec3 delta = p1 - p2;
						float len = length( delta );
						float norm = len / linewidth;

						#ifndef USE_DASH

							#ifdef USE_ALPHA_TO_COVERAGE

								float dnorm = fwidth( norm );
								alpha = 1.0 - smoothstep( 0.5 - dnorm, 0.5 + dnorm, norm );

							#else

								if ( norm > 0.5 ) {

									discard;

								}

							#endif

						#endif

					#else

						#ifdef USE_ALPHA_TO_COVERAGE

							// artifacts appear on some hardware if a derivative is taken within a conditional
							float a = vUv.x;
							float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
							float len2 = a * a + b * b;
							float dlen = fwidth( len2 );

							if ( abs( vUv.y ) > 1.0 ) {

								alpha = 1.0 - smoothstep( 1.0 - dlen, 1.0 + dlen, len2 );

							}

						#else

							if ( abs( vUv.y ) > 1.0 ) {

								float a = vUv.x;
								float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
								float len2 = a * a + b * b;

								if ( len2 > 1.0 ) discard;

							}

						#endif

					#endif

					vec4 diffuseColor = vec4( diffuse, alpha );
					#ifdef USE_COLOR
						#ifdef USE_LINE_COLOR_ALPHA
							diffuseColor *= vLineColor;
						#else
							diffuseColor.rgb *= vLineColor;
						#endif
					#endif

					#include <logdepthbuf_fragment>

					gl_FragColor = diffuseColor;

					#include <tonemapping_fragment>
					#include <${h>=154?"colorspace_fragment":"encodings_fragment"}>
					#include <fog_fragment>
					#include <premultiplied_alpha_fragment>

				}
			`,clipping:!0}),this.isLineMaterial=!0,this.onBeforeCompile=function(){this.transparent?this.defines.USE_LINE_COLOR_ALPHA="1":delete this.defines.USE_LINE_COLOR_ALPHA},Object.defineProperties(this,{color:{enumerable:!0,get:function(){return this.uniforms.diffuse.value},set:function(e){this.uniforms.diffuse.value=e}},worldUnits:{enumerable:!0,get:function(){return"WORLD_UNITS"in this.defines},set:function(e){!0===e?this.defines.WORLD_UNITS="":delete this.defines.WORLD_UNITS}},linewidth:{enumerable:!0,get:function(){return this.uniforms.linewidth.value},set:function(e){this.uniforms.linewidth.value=e}},dashed:{enumerable:!0,get:function(){return"USE_DASH"in this.defines},set(e){!!e!="USE_DASH"in this.defines&&(this.needsUpdate=!0),!0===e?this.defines.USE_DASH="":delete this.defines.USE_DASH}},dashScale:{enumerable:!0,get:function(){return this.uniforms.dashScale.value},set:function(e){this.uniforms.dashScale.value=e}},dashSize:{enumerable:!0,get:function(){return this.uniforms.dashSize.value},set:function(e){this.uniforms.dashSize.value=e}},dashOffset:{enumerable:!0,get:function(){return this.uniforms.dashOffset.value},set:function(e){this.uniforms.dashOffset.value=e}},gapSize:{enumerable:!0,get:function(){return this.uniforms.gapSize.value},set:function(e){this.uniforms.gapSize.value=e}},opacity:{enumerable:!0,get:function(){return this.uniforms.opacity.value},set:function(e){this.uniforms.opacity.value=e}},resolution:{enumerable:!0,get:function(){return this.uniforms.resolution.value},set:function(e){this.uniforms.resolution.value.copy(e)}},alphaToCoverage:{enumerable:!0,get:function(){return"USE_ALPHA_TO_COVERAGE"in this.defines},set:function(e){!!e!="USE_ALPHA_TO_COVERAGE"in this.defines&&(this.needsUpdate=!0),!0===e?(this.defines.USE_ALPHA_TO_COVERAGE="",this.extensions.derivatives=!0):(delete this.defines.USE_ALPHA_TO_COVERAGE,this.extensions.derivatives=!1)}}}),this.setValues(e)}}let x=h>=125?"uv1":"uv2",y=new a.$i,g=new a.cE,v=new a.cE,S=new a.$i,b=new a.$i,w=new a.$i,j=new a.cE,E=new a.nd,_=new a._i,M=new a.cE,A=new a.VQ,L=new a.L0,z=new a.$i;function U(e,t,n){return z.set(0,0,-t,1).applyMatrix4(e.projectionMatrix),z.multiplyScalar(1/z.w),z.x=i/n.width,z.y=i/n.height,z.applyMatrix4(e.projectionMatrixInverse),z.multiplyScalar(1/z.w),Math.abs(Math.max(z.x,z.y))}class O extends a.kE{constructor(e=new f,t=new m({color:0xffffff*Math.random()})){super(e,t),this.isLineSegments2=!0,this.type="LineSegments2"}computeLineDistances(){let e=this.geometry,t=e.attributes.instanceStart,i=e.attributes.instanceEnd,n=new Float32Array(2*t.count);for(let e=0,s=0,r=t.count;e<r;e++,s+=2)g.fromBufferAttribute(t,e),v.fromBufferAttribute(i,e),n[s]=0===s?0:n[s-1],n[s+1]=n[s]+g.distanceTo(v);let s=new a.hC(n,2,1);return e.setAttribute("instanceDistanceStart",new a.Zq(s,1,0)),e.setAttribute("instanceDistanceEnd",new a.Zq(s,1,1)),this}raycast(e,n){let s,r,o=this.material.worldUnits,l=e.camera;null!==l||o||console.error('LineSegments2: "Raycaster.camera" needs to be set in order to raycast against LineSegments2 while worldUnits is set to false.');let c=void 0!==e.params.Line2&&e.params.Line2.threshold||0;t=e.ray;let d=this.matrixWorld,f=this.geometry,u=this.material;if(i=u.linewidth+c,null===f.boundingSphere&&f.computeBoundingSphere(),L.copy(f.boundingSphere).applyMatrix4(d),o)s=.5*i;else{let e=Math.max(l.near,L.distanceToPoint(t.origin));s=U(l,e,u.resolution)}if(L.radius+=s,!1!==t.intersectsSphere(L)){if(null===f.boundingBox&&f.computeBoundingBox(),A.copy(f.boundingBox).applyMatrix4(d),o)r=.5*i;else{let e=Math.max(l.near,A.distanceToPoint(t.origin));r=U(l,e,u.resolution)}A.expandByScalar(r),!1!==t.intersectsBox(A)&&(o?function(e,n){let s=e.matrixWorld,r=e.geometry,o=r.attributes.instanceStart,l=r.attributes.instanceEnd,c=Math.min(r.instanceCount,o.count);for(let r=0;r<c;r++){_.start.fromBufferAttribute(o,r),_.end.fromBufferAttribute(l,r),_.applyMatrix4(s);let c=new a.cE,d=new a.cE;t.distanceSqToSegment(_.start,_.end,d,c),d.distanceTo(c)<.5*i&&n.push({point:d,pointOnLine:c,distance:t.origin.distanceTo(d),object:e,face:null,faceIndex:r,uv:null,[x]:null})}}(this,n):function(e,n,s){let r=n.projectionMatrix,o=e.material.resolution,l=e.matrixWorld,c=e.geometry,d=c.attributes.instanceStart,f=c.attributes.instanceEnd,u=Math.min(c.instanceCount,d.count),p=-n.near;t.at(1,w),w.w=1,w.applyMatrix4(n.matrixWorldInverse),w.applyMatrix4(r),w.multiplyScalar(1/w.w),w.x*=o.x/2,w.y*=o.y/2,w.z=0,j.copy(w),E.multiplyMatrices(n.matrixWorldInverse,l);for(let n=0;n<u;n++){if(S.fromBufferAttribute(d,n),b.fromBufferAttribute(f,n),S.w=1,b.w=1,S.applyMatrix4(E),b.applyMatrix4(E),S.z>p&&b.z>p)continue;if(S.z>p){let e=S.z-b.z,t=(S.z-p)/e;S.lerp(b,t)}else if(b.z>p){let e=b.z-S.z,t=(b.z-p)/e;b.lerp(S,t)}S.applyMatrix4(r),b.applyMatrix4(r),S.multiplyScalar(1/S.w),b.multiplyScalar(1/b.w),S.x*=o.x/2,S.y*=o.y/2,b.x*=o.x/2,b.y*=o.y/2,_.start.copy(S),_.start.z=0,_.end.copy(b),_.end.z=0;let c=_.closestPointToPointParameter(j,!0);_.at(c,M);let u=a.rB.lerp(S.z,b.z,c),h=u>=-1&&u<=1,m=j.distanceTo(M)<.5*i;if(h&&m){_.start.fromBufferAttribute(d,n),_.end.fromBufferAttribute(f,n),_.start.applyMatrix4(l),_.end.applyMatrix4(l);let i=new a.cE,r=new a.cE;t.distanceSqToSegment(_.start,_.end,r,i),s.push({point:r,pointOnLine:i,distance:t.origin.distanceTo(r),object:e,face:null,faceIndex:n,uv:null,[x]:null})}}}(this,l,n))}}onBeforeRender(e){let t=this.material.uniforms;t&&t.resolution&&(e.getViewport(y),this.material.uniforms.resolution.value.set(y.z,y.w))}}class C extends f{constructor(){super(),this.isLineGeometry=!0,this.type="LineGeometry"}setPositions(e){let t=e.length-3,i=new Float32Array(2*t);for(let n=0;n<t;n+=3)i[2*n]=e[n],i[2*n+1]=e[n+1],i[2*n+2]=e[n+2],i[2*n+3]=e[n+3],i[2*n+4]=e[n+4],i[2*n+5]=e[n+5];return super.setPositions(i),this}setColors(e,t=3){let i=e.length-t,n=new Float32Array(2*i);if(3===t)for(let s=0;s<i;s+=t)n[2*s]=e[s],n[2*s+1]=e[s+1],n[2*s+2]=e[s+2],n[2*s+3]=e[s+3],n[2*s+4]=e[s+4],n[2*s+5]=e[s+5];else for(let s=0;s<i;s+=t)n[2*s]=e[s],n[2*s+1]=e[s+1],n[2*s+2]=e[s+2],n[2*s+3]=e[s+3],n[2*s+4]=e[s+4],n[2*s+5]=e[s+5],n[2*s+6]=e[s+6],n[2*s+7]=e[s+7];return super.setColors(n,t),this}fromLine(e){let t=e.geometry;return this.setPositions(t.attributes.position.array),this}}class B extends O{constructor(e=new C,t=new m({color:0xffffff*Math.random()})){super(e,t),this.isLine2=!0,this.type="Line2"}}let P=s.forwardRef(function({points:e,color:t=0xffffff,vertexColors:i,linewidth:a,lineWidth:l,segments:c,dashed:d,...u},p){var h,x;let y=(0,o.f)(e=>e.size),g=s.useMemo(()=>c?new O:new B,[c]),[v]=s.useState(()=>new m),S=(null==i||null==(h=i[0])?void 0:h.length)===4?4:3,b=s.useMemo(()=>{let n=c?new f:new C,s=e.map(e=>{let t=Array.isArray(e);return e instanceof r.cE||e instanceof r.$i?[e.x,e.y,e.z]:e instanceof r.wq?[e.x,e.y,0]:t&&3===e.length?[e[0],e[1],e[2]]:t&&2===e.length?[e[0],e[1],0]:e});if(n.setPositions(s.flat()),i){t=0xffffff;let e=i.map(e=>e instanceof r.Es?e.toArray():e);n.setColors(e.flat(),S)}return n},[e,c,i,S]);return s.useLayoutEffect(()=>{g.computeLineDistances()},[e,g]),s.useLayoutEffect(()=>{d?v.defines.USE_DASH="":delete v.defines.USE_DASH,v.needsUpdate=!0},[d,v]),s.useEffect(()=>()=>{b.dispose(),v.dispose()},[b]),s.createElement("primitive",(0,n.f)({object:g,ref:p},u),s.createElement("primitive",{object:b,attach:"geometry"}),s.createElement("primitive",(0,n.f)({object:v,attach:"material",color:t,vertexColors:!!i,resolution:[y.width,y.height],linewidth:null!=(x=null!=a?a:l)?x:1,dashed:d,transparent:4===S},u)))});e.s(["f",0,P],43216)},72328,71164,38544,e=>{"use strict";let t={current:null},i={current:!1};e.s(["E",0,i,"d",0,t],71164);let n="u">typeof window;function s(){if(i.current=!0,n)if(window.matchMedia){let e=window.matchMedia("(prefers-reduced-motion)"),i=()=>t.current=e.matches;e.addEventListener("change",i),i()}else t.current=!1}e.s(["f",0,s],38544);var r=e.i(71645);e.s(["f",0,function(){i.current||s();let[e]=(0,r.useState)(t.current);return e}],72328)},8155,e=>{"use strict";let t=e=>{let t,i=new Set,n=(e,n)=>{let s="function"==typeof e?e(t):e;if(!Object.is(s,t)){let e=t;t=(null!=n?n:"object"!=typeof s||null===s)?s:Object.assign({},t,s),i.forEach(i=>i(t,e))}},s=()=>t,r={setState:n,getState:s,getInitialState:()=>o,subscribe:e=>(i.add(e),()=>i.delete(e))},o=t=e(n,s,r);return r};e.s(["f",0,e=>e?t(e):t])},70038,e=>{"use strict";var t=e.i(43476),i=e.i(71645),n=e.i(75056),s=e.i(98903),r=e.i(31067),o=e.i(68338),a=e.i(43216);let l=i.forwardRef(({threshold:e=15,geometry:t,...n},s)=>{let l=i.useRef(null);i.useImperativeHandle(s,()=>l.current,[]);let c=i.useMemo(()=>[0,0,0,1,0,0],[]),d=i.useRef(null),f=i.useRef(null);return i.useLayoutEffect(()=>{let i=l.current.parent,n=null!=t?t:null==i?void 0:i.geometry;if(!n||d.current===n&&f.current===e)return;d.current=n,f.current=e;let s=new o.nC(n,e).attributes.position.array;l.current.geometry.setPositions(s),l.current.geometry.attributes.instanceStart.needsUpdate=!0,l.current.geometry.attributes.instanceEnd.needsUpdate=!0,l.current.computeLineDistances()}),i.createElement(a.f,(0,r.f)({segments:!0,points:c,ref:l,raycast:()=>null},n))});var c=e.i(30297),d=e.i(72328);function f({position:e,size:i,color:n="#203744",edge:s="#3e6877"}){return(0,t.jsxs)("mesh",{position:e,children:[(0,t.jsx)("boxGeometry",{args:i}),(0,t.jsx)("meshStandardMaterial",{color:n,metalness:.45,roughness:.58,transparent:!0,opacity:.92}),(0,t.jsx)(l,{color:s,threshold:15})]})}function u({rotation:e=[0,0,0],position:i=[0,0,0],length:n=1.3}){return(0,t.jsxs)("group",{position:i,rotation:e,children:[(0,t.jsxs)("mesh",{position:[0,-n/2,0],children:[(0,t.jsx)("cylinderGeometry",{args:[.035,.045,n,8]}),(0,t.jsx)("meshStandardMaterial",{color:"#7c8b8f",metalness:.7,roughness:.35})]}),(0,t.jsxs)("mesh",{position:[0,-n,0],children:[(0,t.jsx)("cylinderGeometry",{args:[.15,.18,.05,16]}),(0,t.jsx)("meshStandardMaterial",{color:"#b0a37f",metalness:.55,roughness:.5})]})]})}function p(){return(0,t.jsxs)("group",{position:[0,.6,0],children:[(0,t.jsxs)("mesh",{position:[0,-.25,0],children:[(0,t.jsx)("cylinderGeometry",{args:[1.05,1.15,.62,8]}),(0,t.jsx)("meshStandardMaterial",{color:"#233943",metalness:.62,roughness:.46}),(0,t.jsx)(l,{color:"#55808c",threshold:15})]}),(0,t.jsx)(f,{position:[0,.24,0],size:[1.05,.58,1.05]}),(0,t.jsx)(f,{position:[.62,.28,0],size:[.34,.42,.86],color:"#3b3528",edge:"#e4b44c"}),(0,t.jsxs)("mesh",{position:[0,.74,0],children:[(0,t.jsx)("cylinderGeometry",{args:[.2,.24,.58,12]}),(0,t.jsx)("meshStandardMaterial",{color:"#51636a",metalness:.6,roughness:.4}),(0,t.jsx)(l,{color:"#7a949c"})]}),(0,t.jsxs)("mesh",{position:[0,.48,0],rotation:[Math.PI/2,0,0],children:[(0,t.jsx)("torusGeometry",{args:[.35,.02,6,32]}),(0,t.jsx)("meshBasicMaterial",{color:"#e4b44c",transparent:!0,opacity:.7})]}),(0,t.jsxs)("mesh",{position:[0,-.73,0],children:[(0,t.jsx)("cylinderGeometry",{args:[.18,.38,.48,16]}),(0,t.jsx)("meshStandardMaterial",{color:"#4d5b5e",metalness:.8,roughness:.3}),(0,t.jsx)(l,{color:"#8ca1a8"})]}),[0,Math.PI/2,Math.PI,3*Math.PI/2].map((e,i)=>(0,t.jsx)("group",{rotation:[0,e,0],children:(0,t.jsx)(u,{position:[.92,-.4,0],rotation:[0,0,-.4],length:1.05})},i)),(0,t.jsxs)("mesh",{position:[-.65,.72,.2],children:[(0,t.jsx)("cylinderGeometry",{args:[.012,.012,.85,6]}),(0,t.jsx)("meshBasicMaterial",{color:"#c9d3dd"})]}),(0,t.jsxs)("mesh",{position:[-.65,1.15,.2],children:[(0,t.jsx)("sphereGeometry",{args:[.07,12,12]}),(0,t.jsx)("meshBasicMaterial",{color:"#e4b44c"})]})]})}function h(){return(0,t.jsxs)("group",{position:[0,.55,0],children:[(0,t.jsx)(f,{position:[0,.1,0],size:[1.7,.32,.95]}),(0,t.jsx)(f,{position:[-.1,.3,0],size:[1.05,.05,.75],color:"#3b3528",edge:"#e4b44c"}),[[-.55,-.34,-.6],[0,-.34,-.6],[.55,-.34,-.6],[-.55,-.34,.6],[0,-.34,.6],[.55,-.34,.6]].map((e,i)=>(0,t.jsxs)("mesh",{position:e,rotation:[Math.PI/2,0,0],children:[(0,t.jsx)("cylinderGeometry",{args:[.24,.24,.14,18]}),(0,t.jsx)("meshStandardMaterial",{color:"#6e7d82",metalness:.75,roughness:.34}),(0,t.jsx)(l,{color:"#a9bbc0",threshold:20})]},i)),(0,t.jsxs)("mesh",{position:[.45,.55,.24],children:[(0,t.jsx)("cylinderGeometry",{args:[.035,.045,.8,8]}),(0,t.jsx)("meshStandardMaterial",{color:"#8a9a9e",metalness:.8,roughness:.3})]}),(0,t.jsx)(f,{position:[.45,.98,.24],size:[.28,.18,.16]}),(0,t.jsxs)("mesh",{position:[.45,.99,.33],rotation:[Math.PI/2,0,0],children:[(0,t.jsx)("cylinderGeometry",{args:[.07,.07,.07,14]}),(0,t.jsx)("meshStandardMaterial",{color:"#e4b44c",metalness:.6,roughness:.3})]}),(0,t.jsxs)("mesh",{position:[-.76,.25,0],children:[(0,t.jsx)("boxGeometry",{args:[.04,.18,.48]}),(0,t.jsx)("meshBasicMaterial",{color:"#0b7a8f",transparent:!0,opacity:.65})]})]})}function m(){return(0,t.jsxs)("group",{position:[0,.5,0],children:[(0,t.jsxs)("mesh",{position:[0,.15,0],children:[(0,t.jsx)("cylinderGeometry",{args:[.88,.98,.58,8]}),(0,t.jsx)("meshStandardMaterial",{color:"#263b45",metalness:.56,roughness:.5}),(0,t.jsx)(l,{color:"#5d8794",threshold:15})]}),(0,t.jsx)(f,{position:[0,.58,0],size:[.88,.36,.88]}),(0,t.jsxs)("mesh",{position:[.25,.9,.05],children:[(0,t.jsx)("cylinderGeometry",{args:[.02,.02,.9,6]}),(0,t.jsx)("meshBasicMaterial",{color:"#aebbc1"})]}),(0,t.jsxs)("mesh",{position:[.25,1.37,.05],rotation:[.3,0,0],children:[(0,t.jsx)("cylinderGeometry",{args:[.22,.22,.06,18]}),(0,t.jsx)("meshStandardMaterial",{color:"#bdb29a",metalness:.55,roughness:.45}),(0,t.jsx)(l,{color:"#e4b44c"})]}),[0,2*Math.PI/3,4*Math.PI/3].map((e,i)=>(0,t.jsx)("group",{rotation:[0,e,0],children:(0,t.jsx)(u,{position:[.72,-.1,0],rotation:[0,0,-.52],length:1.1})},i)),(0,t.jsxs)("mesh",{position:[-.35,.45,.42],children:[(0,t.jsx)("boxGeometry",{args:[.32,.18,.08]}),(0,t.jsx)("meshBasicMaterial",{color:"#e4b44c",transparent:!0,opacity:.65})]})]})}function x(){return(0,t.jsxs)("group",{position:[0,.35,0],rotation:[0,.35,0],children:[(0,t.jsx)(f,{position:[0,0,0],size:[1.5,1.05,.14],color:"#1a2e39"}),Array.from({length:9}).map((e,i)=>{let n=.33*Math.floor(i/3)-.33;return(0,t.jsxs)("mesh",{position:[i%3*.4-.4,n,.13],children:[(0,t.jsx)("boxGeometry",{args:[.27,.27,.12]}),(0,t.jsx)("meshStandardMaterial",{color:"#d7c28a",metalness:.8,roughness:.25}),(0,t.jsx)(l,{color:"#e4b44c"})]},i)}),(0,t.jsx)(u,{position:[-.55,-.55,0],rotation:[0,0,-.2],length:.9}),(0,t.jsx)(u,{position:[.55,-.55,0],rotation:[0,0,.2],length:.9})]})}function y(){return(0,t.jsxs)("group",{position:[0,.6,0],children:[(0,t.jsx)(f,{position:[0,0,0],size:[1.1,.8,.7]}),(0,t.jsxs)("mesh",{position:[.3,.56,0],children:[(0,t.jsx)("cylinderGeometry",{args:[.05,.05,.7,8]}),(0,t.jsx)("meshStandardMaterial",{color:"#87979b",metalness:.7,roughness:.35})]}),(0,t.jsxs)("mesh",{position:[.3,.94,0],children:[(0,t.jsx)("sphereGeometry",{args:[.11,14,14]}),(0,t.jsx)("meshStandardMaterial",{color:"#e4b44c",metalness:.5,roughness:.4})]}),(0,t.jsxs)("mesh",{position:[0,.1,.42],children:[(0,t.jsx)("cylinderGeometry",{args:[.19,.19,.12,16]}),(0,t.jsx)("meshBasicMaterial",{color:"#0b7a8f",transparent:!0,opacity:.7})]}),[-.3,.3].map(e=>(0,t.jsx)(u,{position:[e,-.4,0],rotation:[0,0,e>0?.25:-.25],length:.8},e))]})}function g({kind:e}){let n=(0,i.useRef)(null),r=(0,d.f)();return(0,s.f)((e,t)=>{n.current&&!r&&(n.current.rotation.y+=.18*t)}),(0,t.jsxs)("group",{ref:n,rotation:[0,-.3,0],children:["lunar-module"===e&&(0,t.jsx)(p,{}),"rover"===e&&(0,t.jsx)(h,{}),"lander"===e&&(0,t.jsx)(m,{}),"retroreflector"===e&&(0,t.jsx)(x,{}),"instrument"===e&&(0,t.jsx)(y,{})]})}e.s(["default",0,function({kind:e}){let i=(0,d.f)();return(0,t.jsxs)(n.f,{dpr:[1,1.6],camera:{position:[0,1.4,5.2],fov:36},gl:{antialias:!0,alpha:!0},frameloop:i?"demand":"always",children:[(0,t.jsx)("ambientLight",{intensity:.7}),(0,t.jsx)("directionalLight",{position:[4,5,5],intensity:3,color:"#fff2d8"}),(0,t.jsx)("pointLight",{position:[-4,1,2],intensity:9,color:"#0b7a8f"}),(0,t.jsx)(g,{kind:e}),(0,t.jsx)("gridHelper",{args:[12,24,"#2b5262","#122835"],position:[0,-1.55,0]}),(0,t.jsxs)("mesh",{rotation:[-Math.PI/2,0,0],position:[0,-1.54,0],children:[(0,t.jsx)("ringGeometry",{args:[1.8,1.84,64]}),(0,t.jsx)("meshBasicMaterial",{color:"#e4b44c",transparent:!0,opacity:.45})]}),(0,t.jsx)(c.f,{enablePan:!1,enableDamping:!0,dampingFactor:.08,minDistance:3.2,maxDistance:8,target:[0,.2,0]})]})}],70038)},62706,function(e){e.n(e.i(70038))}]);