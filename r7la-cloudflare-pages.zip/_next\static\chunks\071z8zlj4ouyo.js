(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,43216,e=>{"use strict";let t,i;var r=e.i(31067),o=e.i(71645),s=e.i(68338),n=e.i(38408),a=s,l=s;let d=new l.VQ,f=new l.cE;class c extends l.Kx{constructor(){super(),this.isLineSegmentsGeometry=!0,this.type="LineSegmentsGeometry",this.setIndex([0,2,1,2,3,1,2,4,3,4,5,3,4,6,5,6,7,5]),this.setAttribute("position",new l.ki([-1,2,0,1,2,0,-1,1,0,1,1,0,-1,0,0,1,0,0,-1,-1,0,1,-1,0],3)),this.setAttribute("uv",new l.ki([-1,2,1,2,-1,1,1,1,-1,-1,1,-1,-1,-2,1,-2],2))}applyMatrix4(e){let t=this.attributes.instanceStart,i=this.attributes.instanceEnd;return void 0!==t&&(t.applyMatrix4(e),i.applyMatrix4(e),t.needsUpdate=!0),null!==this.boundingBox&&this.computeBoundingBox(),null!==this.boundingSphere&&this.computeBoundingSphere(),this}setPositions(e){let t;e instanceof Float32Array?t=e:Array.isArray(e)&&(t=new Float32Array(e));let i=new l.hC(t,6,1);return this.setAttribute("instanceStart",new l.Zq(i,3,0)),this.setAttribute("instanceEnd",new l.Zq(i,3,3)),this.computeBoundingBox(),this.computeBoundingSphere(),this}setColors(e,t=3){let i;e instanceof Float32Array?i=e:Array.isArray(e)&&(i=new Float32Array(e));let r=new l.hC(i,2*t,1);return this.setAttribute("instanceColorStart",new l.Zq(r,t,0)),this.setAttribute("instanceColorEnd",new l.Zq(r,t,t)),this}fromWireframeGeometry(e){return this.setPositions(e.attributes.position.array),this}fromEdgesGeometry(e){return this.setPositions(e.attributes.position.array),this}fromMesh(e){return this.fromWireframeGeometry(new l.nw(e.geometry)),this}fromLineSegments(e){let t=e.geometry;return this.setPositions(t.attributes.position.array),this}computeBoundingBox(){null===this.boundingBox&&(this.boundingBox=new l.VQ);let e=this.attributes.instanceStart,t=this.attributes.instanceEnd;void 0!==e&&void 0!==t&&(this.boundingBox.setFromBufferAttribute(e),d.setFromBufferAttribute(t),this.boundingBox.union(d))}computeBoundingSphere(){null===this.boundingSphere&&(this.boundingSphere=new l.L0),null===this.boundingBox&&this.computeBoundingBox();let e=this.attributes.instanceStart,t=this.attributes.instanceEnd;if(void 0!==e&&void 0!==t){let i=this.boundingSphere.center;this.boundingBox.getCenter(i);let r=0;for(let o=0,s=e.count;o<s;o++)f.fromBufferAttribute(e,o),r=Math.max(r,i.distanceToSquared(f)),f.fromBufferAttribute(t,o),r=Math.max(r,i.distanceToSquared(f));this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&console.error("THREE.LineSegmentsGeometry.computeBoundingSphere(): Computed radius is NaN. The instanced position data is likely to have NaN values.",this)}}toJSON(){}applyMatrix(e){return console.warn("THREE.LineSegmentsGeometry: applyMatrix() has been renamed to applyMatrix4()."),this.applyMatrix4(e)}}var p=s,h=e.i(8560);let u=parseInt(s.Tu.replace(/\D+/g,""));class x extends p.Zg{constructor(e){super({type:"LineMaterial",uniforms:p.SP.clone(p.SP.merge([h.O.common,h.O.fog,{worldUnits:{value:1},linewidth:{value:1},resolution:{value:new p.wq(1,1)},dashOffset:{value:0},dashScale:{value:1},dashSize:{value:1},gapSize:{value:1}}])),vertexShader:`
				#include <common>
				#include <fog_pars_vertex>
				#include <logdepthbuf_pars_vertex>
				#include <clipping_planes_pars_vertex>

				uniform float linewidth;
				uniform vec2 resolution;

				attribute vec3 instanceStart;
				attribute vec3 instanceEnd;

				#ifdef USE_COLOR
					#ifdef USE_LINE_COLOR_ALPHA
						varying vec4 vLineColor;
						attribute vec4 instanceColorStart;
						attribute vec4 instanceColorEnd;
					#else
						varying vec3 vLineColor;
						attribute vec3 instanceColorStart;
						attribute vec3 instanceColorEnd;
					#endif
				#endif

				#ifdef WORLD_UNITS

					varying vec4 worldPos;
					varying vec3 worldStart;
					varying vec3 worldEnd;

					#ifdef USE_DASH

						varying vec2 vUv;

					#endif

				#else

					varying vec2 vUv;

				#endif

				#ifdef USE_DASH

					uniform float dashScale;
					attribute float instanceDistanceStart;
					attribute float instanceDistanceEnd;
					varying float vLineDistance;

				#endif

				void trimSegment( const in vec4 start, inout vec4 end ) {

					// trim end segment so it terminates between the camera plane and the near plane

					// conservative estimate of the near plane
					float a = projectionMatrix[ 2 ][ 2 ]; // 3nd entry in 3th column
					float b = projectionMatrix[ 3 ][ 2 ]; // 3nd entry in 4th column
					float nearEstimate = - 0.5 * b / a;

					float alpha = ( nearEstimate - start.z ) / ( end.z - start.z );

					end.xyz = mix( start.xyz, end.xyz, alpha );

				}

				void main() {

					#ifdef USE_COLOR

						vLineColor = ( position.y < 0.5 ) ? instanceColorStart : instanceColorEnd;

					#endif

					#ifdef USE_DASH

						vLineDistance = ( position.y < 0.5 ) ? dashScale * instanceDistanceStart : dashScale * instanceDistanceEnd;
						vUv = uv;

					#endif

					float aspect = resolution.x / resolution.y;

					// camera space
					vec4 start = modelViewMatrix * vec4( instanceStart, 1.0 );
					vec4 end = modelViewMatrix * vec4( instanceEnd, 1.0 );

					#ifdef WORLD_UNITS

						worldStart = start.xyz;
						worldEnd = end.xyz;

					#else

						vUv = uv;

					#endif

					// special case for perspective projection, and segments that terminate either in, or behind, the camera plane
					// clearly the gpu firmware has a way of addressing this issue when projecting into ndc space
					// but we need to perform ndc-space calculations in the shader, so we must address this issue directly
					// perhaps there is a more elegant solution -- WestLangley

					bool perspective = ( projectionMatrix[ 2 ][ 3 ] == - 1.0 ); // 4th entry in the 3rd column

					if ( perspective ) {

						if ( start.z < 0.0 && end.z >= 0.0 ) {

							trimSegment( start, end );

						} else if ( end.z < 0.0 && start.z >= 0.0 ) {

							trimSegment( end, start );

						}

					}

					// clip space
					vec4 clipStart = projectionMatrix * start;
					vec4 clipEnd = projectionMatrix * end;

					// ndc space
					vec3 ndcStart = clipStart.xyz / clipStart.w;
					vec3 ndcEnd = clipEnd.xyz / clipEnd.w;

					// direction
					vec2 dir = ndcEnd.xy - ndcStart.xy;

					// account for clip-space aspect ratio
					dir.x *= aspect;
					dir = normalize( dir );

					#ifdef WORLD_UNITS

						// get the offset direction as perpendicular to the view vector
						vec3 worldDir = normalize( end.xyz - start.xyz );
						vec3 offset;
						if ( position.y < 0.5 ) {

							offset = normalize( cross( start.xyz, worldDir ) );

						} else {

							offset = normalize( cross( end.xyz, worldDir ) );

						}

						// sign flip
						if ( position.x < 0.0 ) offset *= - 1.0;

						float forwardOffset = dot( worldDir, vec3( 0.0, 0.0, 1.0 ) );

						// don't extend the line if we're rendering dashes because we
						// won't be rendering the endcaps
						#ifndef USE_DASH

							// extend the line bounds to encompass  endcaps
							start.xyz += - worldDir * linewidth * 0.5;
							end.xyz += worldDir * linewidth * 0.5;

							// shift the position of the quad so it hugs the forward edge of the line
							offset.xy -= dir * forwardOffset;
							offset.z += 0.5;

						#endif

						// endcaps
						if ( position.y > 1.0 || position.y < 0.0 ) {

							offset.xy += dir * 2.0 * forwardOffset;

						}

						// adjust for linewidth
						offset *= linewidth * 0.5;

						// set the world position
						worldPos = ( position.y < 0.5 ) ? start : end;
						worldPos.xyz += offset;

						// project the worldpos
						vec4 clip = projectionMatrix * worldPos;

						// shift the depth of the projected points so the line
						// segments overlap neatly
						vec3 clipPose = ( position.y < 0.5 ) ? ndcStart : ndcEnd;
						clip.z = clipPose.z * clip.w;

					#else

						vec2 offset = vec2( dir.y, - dir.x );
						// undo aspect ratio adjustment
						dir.x /= aspect;
						offset.x /= aspect;

						// sign flip
						if ( position.x < 0.0 ) offset *= - 1.0;

						// endcaps
						if ( position.y < 0.0 ) {

							offset += - dir;

						} else if ( position.y > 1.0 ) {

							offset += dir;

						}

						// adjust for linewidth
						offset *= linewidth;

						// adjust for clip-space to screen-space conversion // maybe resolution should be based on viewport ...
						offset /= resolution.y;

						// select end
						vec4 clip = ( position.y < 0.5 ) ? clipStart : clipEnd;

						// back to clip space
						offset *= clip.w;

						clip.xy += offset;

					#endif

					gl_Position = clip;

					vec4 mvPosition = ( position.y < 0.5 ) ? start : end; // this is an approximation

					#include <logdepthbuf_vertex>
					#include <clipping_planes_vertex>
					#include <fog_vertex>

				}
			`,fragmentShader:`
				uniform vec3 diffuse;
				uniform float opacity;
				uniform float linewidth;

				#ifdef USE_DASH

					uniform float dashOffset;
					uniform float dashSize;
					uniform float gapSize;

				#endif

				varying float vLineDistance;

				#ifdef WORLD_UNITS

					varying vec4 worldPos;
					varying vec3 worldStart;
					varying vec3 worldEnd;

					#ifdef USE_DASH

						varying vec2 vUv;

					#endif

				#else

					varying vec2 vUv;

				#endif

				#include <common>
				#include <fog_pars_fragment>
				#include <logdepthbuf_pars_fragment>
				#include <clipping_planes_pars_fragment>

				#ifdef USE_COLOR
					#ifdef USE_LINE_COLOR_ALPHA
						varying vec4 vLineColor;
					#else
						varying vec3 vLineColor;
					#endif
				#endif

				vec2 closestLineToLine(vec3 p1, vec3 p2, vec3 p3, vec3 p4) {

					float mua;
					float mub;

					vec3 p13 = p1 - p3;
					vec3 p43 = p4 - p3;

					vec3 p21 = p2 - p1;

					float d1343 = dot( p13, p43 );
					float d4321 = dot( p43, p21 );
					float d1321 = dot( p13, p21 );
					float d4343 = dot( p43, p43 );
					float d2121 = dot( p21, p21 );

					float denom = d2121 * d4343 - d4321 * d4321;

					float numer = d1343 * d4321 - d1321 * d4343;

					mua = numer / denom;
					mua = clamp( mua, 0.0, 1.0 );
					mub = ( d1343 + d4321 * ( mua ) ) / d4343;
					mub = clamp( mub, 0.0, 1.0 );

					return vec2( mua, mub );

				}

				void main() {

					#include <clipping_planes_fragment>

					#ifdef USE_DASH

						if ( vUv.y < - 1.0 || vUv.y > 1.0 ) discard; // discard endcaps

						if ( mod( vLineDistance + dashOffset, dashSize + gapSize ) > dashSize ) discard; // todo - FIX

					#endif

					float alpha = opacity;

					#ifdef WORLD_UNITS

						// Find the closest points on the view ray and the line segment
						vec3 rayEnd = normalize( worldPos.xyz ) * 1e5;
						vec3 lineDir = worldEnd - worldStart;
						vec2 params = closestLineToLine( worldStart, worldEnd, vec3( 0.0, 0.0, 0.0 ), rayEnd );

						vec3 p1 = worldStart + lineDir * params.x;
						vec3 p2 = rayEnd * params.y;
						vec3 delta = p1 - p2;
						float len = length( delta );
						float norm = len / linewidth;

						#ifndef USE_DASH

							#ifdef USE_ALPHA_TO_COVERAGE

								float dnorm = fwidth( norm );
								alpha = 1.0 - smoothstep( 0.5 - dnorm, 0.5 + dnorm, norm );

							#else

								if ( norm > 0.5 ) {

									discard;

								}

							#endif

						#endif

					#else

						#ifdef USE_ALPHA_TO_COVERAGE

							// artifacts appear on some hardware if a derivative is taken within a conditional
							float a = vUv.x;
							float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
							float len2 = a * a + b * b;
							float dlen = fwidth( len2 );

							if ( abs( vUv.y ) > 1.0 ) {

								alpha = 1.0 - smoothstep( 1.0 - dlen, 1.0 + dlen, len2 );

							}

						#else

							if ( abs( vUv.y ) > 1.0 ) {

								float a = vUv.x;
								float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
								float len2 = a * a + b * b;

								if ( len2 > 1.0 ) discard;

							}

						#endif

					#endif

					vec4 diffuseColor = vec4( diffuse, alpha );
					#ifdef USE_COLOR
						#ifdef USE_LINE_COLOR_ALPHA
							diffuseColor *= vLineColor;
						#else
							diffuseColor.rgb *= vLineColor;
						#endif
					#endif

					#include <logdepthbuf_fragment>

					gl_FragColor = diffuseColor;

					#include <tonemapping_fragment>
					#include <${u>=154?"colorspace_fragment":"encodings_fragment"}>
					#include <fog_fragment>
					#include <premultiplied_alpha_fragment>

				}
			`,clipping:!0}),this.isLineMaterial=!0,this.onBeforeCompile=function(){this.transparent?this.defines.USE_LINE_COLOR_ALPHA="1":delete this.defines.USE_LINE_COLOR_ALPHA},Object.defineProperties(this,{color:{enumerable:!0,get:function(){return this.uniforms.diffuse.value},set:function(e){this.uniforms.diffuse.value=e}},worldUnits:{enumerable:!0,get:function(){return"WORLD_UNITS"in this.defines},set:function(e){!0===e?this.defines.WORLD_UNITS="":delete this.defines.WORLD_UNITS}},linewidth:{enumerable:!0,get:function(){return this.uniforms.linewidth.value},set:function(e){this.uniforms.linewidth.value=e}},dashed:{enumerable:!0,get:function(){return"USE_DASH"in this.defines},set(e){!!e!="USE_DASH"in this.defines&&(this.needsUpdate=!0),!0===e?this.defines.USE_DASH="":delete this.defines.USE_DASH}},dashScale:{enumerable:!0,get:function(){return this.uniforms.dashScale.value},set:function(e){this.uniforms.dashScale.value=e}},dashSize:{enumerable:!0,get:function(){return this.uniforms.dashSize.value},set:function(e){this.uniforms.dashSize.value=e}},dashOffset:{enumerable:!0,get:function(){return this.uniforms.dashOffset.value},set:function(e){this.uniforms.dashOffset.value=e}},gapSize:{enumerable:!0,get:function(){return this.uniforms.gapSize.value},set:function(e){this.uniforms.gapSize.value=e}},opacity:{enumerable:!0,get:function(){return this.uniforms.opacity.value},set:function(e){this.uniforms.opacity.value=e}},resolution:{enumerable:!0,get:function(){return this.uniforms.resolution.value},set:function(e){this.uniforms.resolution.value.copy(e)}},alphaToCoverage:{enumerable:!0,get:function(){return"USE_ALPHA_TO_COVERAGE"in this.defines},set:function(e){!!e!="USE_ALPHA_TO_COVERAGE"in this.defines&&(this.needsUpdate=!0),!0===e?(this.defines.USE_ALPHA_TO_COVERAGE="",this.extensions.derivatives=!0):(delete this.defines.USE_ALPHA_TO_COVERAGE,this.extensions.derivatives=!1)}}}),this.setValues(e)}}let m=u>=125?"uv1":"uv2",y=new a.$i,v=new a.cE,g=new a.cE,b=new a.$i,w=new a.$i,S=new a.$i,j=new a.cE,k=new a.nd,L=new a._i,M=new a.cE,E=new a.VQ,_=new a.L0,C=new a.$i;function A(e,t,r){return C.set(0,0,-t,1).applyMatrix4(e.projectionMatrix),C.multiplyScalar(1/C.w),C.x=i/r.width,C.y=i/r.height,C.applyMatrix4(e.projectionMatrixInverse),C.multiplyScalar(1/C.w),Math.abs(Math.max(C.x,C.y))}class z extends a.kE{constructor(e=new c,t=new x({color:0xffffff*Math.random()})){super(e,t),this.isLineSegments2=!0,this.type="LineSegments2"}computeLineDistances(){let e=this.geometry,t=e.attributes.instanceStart,i=e.attributes.instanceEnd,r=new Float32Array(2*t.count);for(let e=0,o=0,s=t.count;e<s;e++,o+=2)v.fromBufferAttribute(t,e),g.fromBufferAttribute(i,e),r[o]=0===o?0:r[o-1],r[o+1]=r[o]+v.distanceTo(g);let o=new a.hC(r,2,1);return e.setAttribute("instanceDistanceStart",new a.Zq(o,1,0)),e.setAttribute("instanceDistanceEnd",new a.Zq(o,1,1)),this}raycast(e,r){let o,s,n=this.material.worldUnits,l=e.camera;null!==l||n||console.error('LineSegments2: "Raycaster.camera" needs to be set in order to raycast against LineSegments2 while worldUnits is set to false.');let d=void 0!==e.params.Line2&&e.params.Line2.threshold||0;t=e.ray;let f=this.matrixWorld,c=this.geometry,p=this.material;if(i=p.linewidth+d,null===c.boundingSphere&&c.computeBoundingSphere(),_.copy(c.boundingSphere).applyMatrix4(f),n)o=.5*i;else{let e=Math.max(l.near,_.distanceToPoint(t.origin));o=A(l,e,p.resolution)}if(_.radius+=o,!1!==t.intersectsSphere(_)){if(null===c.boundingBox&&c.computeBoundingBox(),E.copy(c.boundingBox).applyMatrix4(f),n)s=.5*i;else{let e=Math.max(l.near,E.distanceToPoint(t.origin));s=A(l,e,p.resolution)}E.expandByScalar(s),!1!==t.intersectsBox(E)&&(n?function(e,r){let o=e.matrixWorld,s=e.geometry,n=s.attributes.instanceStart,l=s.attributes.instanceEnd,d=Math.min(s.instanceCount,n.count);for(let s=0;s<d;s++){L.start.fromBufferAttribute(n,s),L.end.fromBufferAttribute(l,s),L.applyMatrix4(o);let d=new a.cE,f=new a.cE;t.distanceSqToSegment(L.start,L.end,f,d),f.distanceTo(d)<.5*i&&r.push({point:f,pointOnLine:d,distance:t.origin.distanceTo(f),object:e,face:null,faceIndex:s,uv:null,[m]:null})}}(this,r):function(e,r,o){let s=r.projectionMatrix,n=e.material.resolution,l=e.matrixWorld,d=e.geometry,f=d.attributes.instanceStart,c=d.attributes.instanceEnd,p=Math.min(d.instanceCount,f.count),h=-r.near;t.at(1,S),S.w=1,S.applyMatrix4(r.matrixWorldInverse),S.applyMatrix4(s),S.multiplyScalar(1/S.w),S.x*=n.x/2,S.y*=n.y/2,S.z=0,j.copy(S),k.multiplyMatrices(r.matrixWorldInverse,l);for(let r=0;r<p;r++){if(b.fromBufferAttribute(f,r),w.fromBufferAttribute(c,r),b.w=1,w.w=1,b.applyMatrix4(k),w.applyMatrix4(k),b.z>h&&w.z>h)continue;if(b.z>h){let e=b.z-w.z,t=(b.z-h)/e;b.lerp(w,t)}else if(w.z>h){let e=w.z-b.z,t=(w.z-h)/e;w.lerp(b,t)}b.applyMatrix4(s),w.applyMatrix4(s),b.multiplyScalar(1/b.w),w.multiplyScalar(1/w.w),b.x*=n.x/2,b.y*=n.y/2,w.x*=n.x/2,w.y*=n.y/2,L.start.copy(b),L.start.z=0,L.end.copy(w),L.end.z=0;let d=L.closestPointToPointParameter(j,!0);L.at(d,M);let p=a.rB.lerp(b.z,w.z,d),u=p>=-1&&p<=1,x=j.distanceTo(M)<.5*i;if(u&&x){L.start.fromBufferAttribute(f,r),L.end.fromBufferAttribute(c,r),L.start.applyMatrix4(l),L.end.applyMatrix4(l);let i=new a.cE,s=new a.cE;t.distanceSqToSegment(L.start,L.end,s,i),o.push({point:s,pointOnLine:i,distance:t.origin.distanceTo(s),object:e,face:null,faceIndex:r,uv:null,[m]:null})}}}(this,l,r))}}onBeforeRender(e){let t=this.material.uniforms;t&&t.resolution&&(e.getViewport(y),this.material.uniforms.resolution.value.set(y.z,y.w))}}class Q extends c{constructor(){super(),this.isLineGeometry=!0,this.type="LineGeometry"}setPositions(e){let t=e.length-3,i=new Float32Array(2*t);for(let r=0;r<t;r+=3)i[2*r]=e[r],i[2*r+1]=e[r+1],i[2*r+2]=e[r+2],i[2*r+3]=e[r+3],i[2*r+4]=e[r+4],i[2*r+5]=e[r+5];return super.setPositions(i),this}setColors(e,t=3){let i=e.length-t,r=new Float32Array(2*i);if(3===t)for(let o=0;o<i;o+=t)r[2*o]=e[o],r[2*o+1]=e[o+1],r[2*o+2]=e[o+2],r[2*o+3]=e[o+3],r[2*o+4]=e[o+4],r[2*o+5]=e[o+5];else for(let o=0;o<i;o+=t)r[2*o]=e[o],r[2*o+1]=e[o+1],r[2*o+2]=e[o+2],r[2*o+3]=e[o+3],r[2*o+4]=e[o+4],r[2*o+5]=e[o+5],r[2*o+6]=e[o+6],r[2*o+7]=e[o+7];return super.setColors(r,t),this}fromLine(e){let t=e.geometry;return this.setPositions(t.attributes.position.array),this}}class U extends z{constructor(e=new Q,t=new x({color:0xffffff*Math.random()})){super(e,t),this.isLine2=!0,this.type="Line2"}}let W=o.forwardRef(function({points:e,color:t=0xffffff,vertexColors:i,linewidth:a,lineWidth:l,segments:d,dashed:f,...p},h){var u,m;let y=(0,n.f)(e=>e.size),v=o.useMemo(()=>d?new z:new U,[d]),[g]=o.useState(()=>new x),b=(null==i||null==(u=i[0])?void 0:u.length)===4?4:3,w=o.useMemo(()=>{let r=d?new c:new Q,o=e.map(e=>{let t=Array.isArray(e);return e instanceof s.cE||e instanceof s.$i?[e.x,e.y,e.z]:e instanceof s.wq?[e.x,e.y,0]:t&&3===e.length?[e[0],e[1],e[2]]:t&&2===e.length?[e[0],e[1],0]:e});if(r.setPositions(o.flat()),i){t=0xffffff;let e=i.map(e=>e instanceof s.Es?e.toArray():e);r.setColors(e.flat(),b)}return r},[e,d,i,b]);return o.useLayoutEffect(()=>{v.computeLineDistances()},[e,v]),o.useLayoutEffect(()=>{f?g.defines.USE_DASH="":delete g.defines.USE_DASH,g.needsUpdate=!0},[f,g]),o.useEffect(()=>()=>{w.dispose(),g.dispose()},[w]),o.createElement("primitive",(0,r.f)({object:v,ref:h},p),o.createElement("primitive",{object:w,attach:"geometry"}),o.createElement("primitive",(0,r.f)({object:g,attach:"material",color:t,vertexColors:!!i,resolution:[y.width,y.height],linewidth:null!=(m=null!=a?a:l)?m:1,dashed:f,transparent:4===b},p)))});e.s(["f",0,W],43216)},11241,24071,67927,26150,e=>{"use strict";var t=e.i(56420);let i={name:"arrow-left",size:24,node:[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]]};i.node;let r=(0,t.f)(i);e.s(["f",0,r],11241);let o={name:"chevron-left",size:24,node:[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]};o.node;let s=(0,t.f)(o);e.s(["f",0,s],24071);let n={name:"chevron-right",size:24,node:[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]};n.node;let a=(0,t.f)(n);e.s(["f",0,a],67927);let l={name:"volume-x",size:24,node:[["path",{d:"M11 4.702a.7.7 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.7.7 0 0 0 11 19.298z",key:"1p7khw"}],["path",{d:"m16.5 14.5 5-5",key:"cul3yw"}],["path",{d:"m16.5 9.5 5 5",key:"1akey5"}]]};l.node;let d=(0,t.f)(l);e.s(["f",0,d],26150)},95925,e=>{"use strict";var t=e.i(56420);let i={name:"rotate-ccw",size:24,node:[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]]};i.node;let r=(0,t.f)(i);e.s(["f",0,r],95925)},23827,e=>{"use strict";var t=e.i(56420);let i={name:"volume-2",size:24,node:[["path",{d:"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",key:"uqj9uw"}],["path",{d:"M16 9a5 5 0 0 1 0 6",key:"1q6k2b"}],["path",{d:"M19.364 18.364a9 9 0 0 0 0-12.728",key:"ijwkga"}]]};i.node;let r=(0,t.f)(i);e.s(["f",0,r],23827)},10539,e=>{"use strict";var t=e.i(43476),i=e.i(75157);let r={idle:"",walk:"rotate(-3 130 330)",point:"rotate(-2 130 330)",inspect:"rotate(5 130 330)",think:"rotate(-5 130 330)",celebrate:"translate(0 -8)",transmit:"rotate(-2 130 330)","low-power":"rotate(7 130 330) translate(0 8)"};function o({expression:e}){return"focused"===e?(0,t.jsxs)("g",{fill:"none",stroke:"#62ecff",strokeWidth:"7",strokeLinecap:"round",children:[(0,t.jsx)("path",{d:"M93 113 L116 119"}),(0,t.jsx)("path",{d:"M167 113 L144 119"})]}):"concerned"===e?(0,t.jsxs)("g",{fill:"none",stroke:"#62ecff",strokeWidth:"7",strokeLinecap:"round",children:[(0,t.jsx)("path",{d:"M91 117 Q104 106 118 116"}),(0,t.jsx)("path",{d:"M142 116 Q156 106 169 117"})]}):"curious"===e?(0,t.jsxs)("g",{fill:"none",stroke:"#62ecff",strokeLinecap:"round",children:[(0,t.jsx)("path",{d:"M91 119 Q105 104 119 119",strokeWidth:"7"}),(0,t.jsx)("circle",{cx:"155",cy:"114",r:"7",fill:"#62ecff",stroke:"none"})]}):"excited"===e?(0,t.jsxs)("g",{fill:"none",stroke:"#62ecff",strokeWidth:"7",strokeLinecap:"round",children:[(0,t.jsx)("path",{d:"M91 121 Q105 103 119 121"}),(0,t.jsx)("path",{d:"M142 121 Q156 103 170 121"}),(0,t.jsx)("path",{d:"M84 92 L88 83",strokeWidth:"4"}),(0,t.jsx)("path",{d:"M176 92 L172 83",strokeWidth:"4"})]}):(0,t.jsxs)("g",{fill:"none",stroke:"#62ecff",strokeWidth:"7",strokeLinecap:"round",children:[(0,t.jsx)("path",{d:"M91 120 Q105 107 119 120"}),(0,t.jsx)("path",{d:"M142 120 Q156 107 170 120"})]})}e.s(["l",0,function({pose:e="idle",expression:s="content",className:n,glow:a=!0}){let l="celebrate"===e?"rotate(138 80 178)":"point"===e||"transmit"===e?"rotate(-28 80 178)":"inspect"===e?"rotate(38 80 178)":"think"===e?"rotate(24 80 178)":"low-power"===e?"rotate(8 80 178)":"rotate(2 80 178)",d="celebrate"===e?"rotate(-138 180 178)":"point"===e?"rotate(28 180 178)":"transmit"===e?"rotate(35 180 178)":"inspect"===e?"rotate(-58 180 178)":"think"===e?"rotate(-142 180 178)":"low-power"===e?"rotate(-7 180 178)":"rotate(-2 180 178)";return(0,t.jsxs)("svg",{viewBox:"0 0 260 360",className:(0,i.f)("block overflow-visible",n),"aria-hidden":"true",children:[(0,t.jsxs)("defs",{children:[(0,t.jsxs)("linearGradient",{id:"rex-armor",x1:"0",y1:"0",x2:"1",y2:"1",children:[(0,t.jsx)("stop",{offset:"0",stopColor:"#fffdf7"}),(0,t.jsx)("stop",{offset:".52",stopColor:"#dce0e2"}),(0,t.jsx)("stop",{offset:"1",stopColor:"#929da2"})]}),(0,t.jsxs)("linearGradient",{id:"rex-dark",x1:"0",y1:"0",x2:"0",y2:"1",children:[(0,t.jsx)("stop",{offset:"0",stopColor:"#2a3c46"}),(0,t.jsx)("stop",{offset:"1",stopColor:"#070e13"})]}),(0,t.jsxs)("linearGradient",{id:"rex-gold",x1:"0",y1:"0",x2:"1",y2:"1",children:[(0,t.jsx)("stop",{offset:"0",stopColor:"#e9fdff"}),(0,t.jsx)("stop",{offset:".55",stopColor:"#58c8e8"}),(0,t.jsx)("stop",{offset:"1",stopColor:"#577887"})]}),(0,t.jsxs)("radialGradient",{id:"rex-visor",cx:".38",cy:".28",r:".8",children:[(0,t.jsx)("stop",{offset:"0",stopColor:"#1e3846"}),(0,t.jsx)("stop",{offset:".55",stopColor:"#071017"}),(0,t.jsx)("stop",{offset:"1",stopColor:"#02070b"})]}),(0,t.jsxs)("filter",{id:"rex-cyan-glow",x:"-60%",y:"-60%",width:"220%",height:"220%",children:[(0,t.jsx)("feGaussianBlur",{stdDeviation:"4",result:"blur"}),(0,t.jsxs)("feMerge",{children:[(0,t.jsx)("feMergeNode",{in:"blur"}),(0,t.jsx)("feMergeNode",{in:"SourceGraphic"})]})]}),a&&(0,t.jsxs)("filter",{id:"rex-body-glow",x:"-30%",y:"-30%",width:"160%",height:"160%",children:[(0,t.jsx)("feGaussianBlur",{stdDeviation:"7",result:"blur"}),(0,t.jsx)("feColorMatrix",{in:"blur",type:"matrix",values:"0 0 0 0 0.04  0 0 0 0 0.55  0 0 0 0 0.68  0 0 0 .35 0"})]})]}),(0,t.jsx)("ellipse",{cx:"130",cy:"344",rx:"72",ry:"11",fill:"#031018",opacity:".65"}),a&&(0,t.jsx)("ellipse",{cx:"130",cy:"194",rx:"98",ry:"154",fill:"none",stroke:"#0b7a8f",strokeWidth:"2",opacity:".15",filter:"url(#rex-body-glow)"}),(0,t.jsxs)("g",{transform:r[e],children:[(0,t.jsxs)("g",{transform:"walk"===e?"rotate(-11 99 282)":"rotate(0 99 282)",children:[(0,t.jsx)("rect",{x:"87",y:"250",width:"24",height:"32",rx:"10",fill:"#111b21"}),(0,t.jsx)("path",{d:"M78 272 Q90 264 111 274 L111 317 Q96 326 77 319Z",fill:"url(#rex-armor)",stroke:"#77848b",strokeWidth:"1.4"}),(0,t.jsx)("rect",{x:"83",y:"314",width:"37",height:"23",rx:"9",fill:"url(#rex-dark)",stroke:"#4a5b63"}),(0,t.jsx)("path",{d:"M85 329 H117",stroke:"#62ecff",strokeWidth:"3.5",filter:"url(#rex-cyan-glow)"}),(0,t.jsx)("circle",{cx:"99",cy:"289",r:"4",fill:"#0b7a8f"})]}),(0,t.jsxs)("g",{transform:"walk"===e?"rotate(12 161 282)":"rotate(0 161 282)",children:[(0,t.jsx)("rect",{x:"149",y:"250",width:"24",height:"32",rx:"10",fill:"#111b21"}),(0,t.jsx)("path",{d:"M149 274 Q170 264 182 272 L183 319 Q164 326 149 317Z",fill:"url(#rex-armor)",stroke:"#77848b",strokeWidth:"1.4"}),(0,t.jsx)("rect",{x:"140",y:"314",width:"37",height:"23",rx:"9",fill:"url(#rex-dark)",stroke:"#4a5b63"}),(0,t.jsx)("path",{d:"M143 329 H175",stroke:"#62ecff",strokeWidth:"3.5",filter:"url(#rex-cyan-glow)"}),(0,t.jsx)("circle",{cx:"161",cy:"289",r:"4",fill:"#0b7a8f"})]}),(0,t.jsx)("path",{d:"M105 226 Q130 216 155 226 L161 274 Q130 285 99 274Z",fill:"url(#rex-dark)",stroke:"#374a53"}),(0,t.jsx)("path",{d:"M100 196 Q130 183 160 196 L158 244 Q130 255 102 244Z",fill:"url(#rex-armor)",stroke:"#77848b",strokeWidth:"1.6"}),(0,t.jsx)("path",{d:"M108 199 Q130 190 152 199 L151 236 Q130 244 109 236Z",fill:"#c9d0d3",opacity:".55"}),(0,t.jsx)("path",{d:"M130 205 L145 229 L115 229Z",fill:"#0b7a8f",stroke:"#39b9c9",strokeWidth:"2"}),(0,t.jsx)("path",{d:"M130 212 L136 224 L124 224Z",fill:"#62ecff",opacity:".65"}),(0,t.jsx)("circle",{cx:"106",cy:"246",r:"4",fill:"#58c8e8"}),(0,t.jsx)("circle",{cx:"154",cy:"246",r:"4",fill:"#58c8e8"}),(0,t.jsxs)("g",{transform:l,children:[(0,t.jsx)("circle",{cx:"88",cy:"185",r:"19",fill:"url(#rex-gold)",stroke:"#8b6824",strokeWidth:"1.2"}),(0,t.jsx)("rect",{x:"66",y:"198",width:"29",height:"53",rx:"13",fill:"url(#rex-armor)",stroke:"#77848b"}),(0,t.jsx)("rect",{x:"70",y:"244",width:"22",height:"21",rx:"8",fill:"#111b21"}),(0,t.jsx)("path",{d:"M71 263 Q81 254 91 263 L94 283 Q82 291 69 282Z",fill:"url(#rex-armor)",stroke:"#6f7b80"}),(0,t.jsx)("path",{d:"M71 285 Q82 291 94 284 L94 297 Q80 304 68 296Z",fill:"url(#rex-dark)"}),(0,t.jsx)("path",{d:"M78 217 H84",stroke:"#62ecff",strokeWidth:"3",strokeLinecap:"round"})]}),(0,t.jsxs)("g",{transform:d,children:[(0,t.jsx)("circle",{cx:"172",cy:"185",r:"19",fill:"url(#rex-gold)",stroke:"#8b6824",strokeWidth:"1.2"}),(0,t.jsx)("rect",{x:"165",y:"198",width:"29",height:"53",rx:"13",fill:"url(#rex-armor)",stroke:"#77848b"}),(0,t.jsx)("rect",{x:"168",y:"244",width:"22",height:"21",rx:"8",fill:"#111b21"}),(0,t.jsx)("path",{d:"M169 263 Q179 254 189 263 L192 283 Q180 291 167 282Z",fill:"url(#rex-armor)",stroke:"#6f7b80"}),(0,t.jsx)("path",{d:"M169 285 Q180 291 192 284 L192 297 Q178 304 166 296Z",fill:"url(#rex-dark)"}),(0,t.jsx)("path",{d:"M176 217 H182",stroke:"#62ecff",strokeWidth:"3",strokeLinecap:"round"})]}),(0,t.jsxs)("g",{transform:"think"===e?"rotate(-5 130 137)":"inspect"===e?"rotate(4 130 137)":"low-power"===e?"translate(0 6) rotate(7 130 137)":"rotate(0 130 137)",children:[(0,t.jsx)("path",{d:"M69 58 Q130 31 191 58 Q223 73 221 123 Q219 176 177 201 Q130 220 83 201 Q41 176 39 123 Q37 73 69 58Z",fill:"url(#rex-armor)",stroke:"#77848b",strokeWidth:"2"}),(0,t.jsx)("path",{d:"M178 55 Q214 65 221 109 L212 102 Q202 74 174 64Z",fill:"url(#rex-gold)",opacity:".92"}),(0,t.jsx)("path",{d:"M60 76 Q78 122 74 188",fill:"none",stroke:"#fff",strokeWidth:"6",strokeLinecap:"round",opacity:".55"}),(0,t.jsx)("path",{d:"M74 85 Q130 58 186 85 Q202 96 201 128 Q199 169 163 186 Q130 199 97 186 Q61 169 59 128 Q58 96 74 85Z",fill:"url(#rex-visor)",stroke:"#101e27",strokeWidth:"3"}),(0,t.jsx)("path",{d:"M78 96 Q103 76 139 80",fill:"none",stroke:"#8ff4ff",strokeWidth:"3.5",strokeLinecap:"round",opacity:".7"}),(0,t.jsxs)("g",{transform:"translate(0 -4)",children:[(0,t.jsx)(o,{expression:s}),"concerned"===s?(0,t.jsx)("path",{d:"M117 173 Q130 166 143 173",fill:"none",stroke:"#62ecff",strokeWidth:"4",strokeLinecap:"round"}):(0,t.jsx)("path",{d:"M117 171 Q130 180 143 171",fill:"none",stroke:"#62ecff",strokeWidth:"4",strokeLinecap:"round"})]}),(0,t.jsxs)("g",{children:[(0,t.jsx)("ellipse",{cx:"43",cy:"133",rx:"18",ry:"29",fill:"url(#rex-gold)"}),(0,t.jsx)("ellipse",{cx:"43",cy:"133",rx:"12",ry:"21",fill:"#07131c",stroke:"#58e8fa",strokeWidth:"3"}),(0,t.jsx)("ellipse",{cx:"217",cy:"133",rx:"18",ry:"29",fill:"url(#rex-gold)"}),(0,t.jsx)("ellipse",{cx:"217",cy:"133",rx:"12",ry:"21",fill:"#07131c",stroke:"#58e8fa",strokeWidth:"3"})]}),(0,t.jsx)("path",{d:"M130 58 L130 27",stroke:"#9aabb3",strokeWidth:"5",strokeLinecap:"round"}),(0,t.jsx)("circle",{cx:"130",cy:"19",r:"8",fill:"#57d9ff",filter:"url(#rex-cyan-glow)"}),(0,t.jsx)("path",{d:"M96 61 Q130 48 164 61",fill:"none",stroke:"#d9ecf1",strokeWidth:"2",opacity:".45"}),(0,t.jsx)("path",{d:"M79 204 Q130 222 181 204 L174 222 Q130 232 86 222Z",fill:"#10181d"})]})]}),"transmit"===e&&(0,t.jsxs)("g",{fill:"none",stroke:"#62ecff",strokeLinecap:"round",filter:"url(#rex-cyan-glow)",children:[(0,t.jsx)("path",{d:"M198 176 Q217 153 218 126",strokeWidth:"2",strokeDasharray:"4 6"}),(0,t.jsx)("path",{d:"M209 186 Q234 154 234 119",strokeWidth:"1.5",strokeDasharray:"3 7",opacity:".65"})]}),"low-power"===e&&(0,t.jsxs)("g",{opacity:".65",children:[(0,t.jsx)("circle",{cx:"130",cy:"182",r:"3",fill:"#58c8e8"}),(0,t.jsx)("text",{x:"138",y:"186",fill:"#58c8e8",fontSize:"9",fontFamily:"monospace",children:"LOW"})]})]})},"p",0,function({className:e,expression:r="content"}){return(0,t.jsxs)("svg",{viewBox:"0 0 260 210",className:(0,i.f)("block",e),"aria-hidden":"true",children:[(0,t.jsxs)("defs",{children:[(0,t.jsxs)("linearGradient",{id:"rex-head-shell",x1:"0",y1:"0",x2:"1",y2:"1",children:[(0,t.jsx)("stop",{offset:"0",stopColor:"#fffdf7"}),(0,t.jsx)("stop",{offset:".58",stopColor:"#d9dde0"}),(0,t.jsx)("stop",{offset:"1",stopColor:"#9fa8ad"})]}),(0,t.jsxs)("radialGradient",{id:"rex-visor-short",cx:".38",cy:".28",r:".8",children:[(0,t.jsx)("stop",{offset:"0",stopColor:"#1d3340"}),(0,t.jsx)("stop",{offset:".55",stopColor:"#071017"}),(0,t.jsx)("stop",{offset:"1",stopColor:"#02070b"})]})]}),(0,t.jsx)("path",{d:"M71 22 Q130 3 189 22 Q221 35 220 82 Q218 136 176 165 Q130 184 84 165 Q42 136 40 82 Q39 35 71 22Z",fill:"url(#rex-head-shell)",stroke:"#77848b",strokeWidth:"2"}),(0,t.jsx)("path",{d:"M176 20 Q212 29 220 69 L211 63 Q202 36 174 27Z",fill:"#58c8e8",opacity:".9"}),(0,t.jsx)("path",{d:"M61 34 Q79 74 74 147",fill:"none",stroke:"#ffffff",strokeWidth:"5",strokeLinecap:"round",opacity:".65"}),(0,t.jsx)("path",{d:"M76 49 Q130 21 185 49 Q202 60 201 91 Q199 133 162 150 Q130 163 98 150 Q61 133 59 91 Q58 60 76 49Z",fill:"url(#rex-visor-short)",stroke:"#101e27",strokeWidth:"3"}),(0,t.jsx)("path",{d:"M79 63 Q102 42 139 47",fill:"none",stroke:"#7cf3ff",strokeWidth:"3.5",strokeLinecap:"round",opacity:".65"}),(0,t.jsx)(o,{expression:r}),"concerned"===r?(0,t.jsx)("path",{d:"M118 139 Q130 132 142 139",fill:"none",stroke:"#62ecff",strokeWidth:"4",strokeLinecap:"round"}):(0,t.jsx)("path",{d:"M117 137 Q130 146 143 137",fill:"none",stroke:"#62ecff",strokeWidth:"4",strokeLinecap:"round"}),(0,t.jsxs)("g",{children:[(0,t.jsx)("ellipse",{cx:"45",cy:"99",rx:"18",ry:"28",fill:"#58c8e8"}),(0,t.jsx)("ellipse",{cx:"45",cy:"99",rx:"12",ry:"20",fill:"#0a1720",stroke:"#58e8fa",strokeWidth:"3"}),(0,t.jsx)("ellipse",{cx:"215",cy:"99",rx:"18",ry:"28",fill:"#58c8e8"}),(0,t.jsx)("ellipse",{cx:"215",cy:"99",rx:"12",ry:"20",fill:"#0a1720",stroke:"#58e8fa",strokeWidth:"3"})]}),(0,t.jsx)("path",{d:"M130 27 L130 12",stroke:"#9aabb3",strokeWidth:"4",strokeLinecap:"round"}),(0,t.jsx)("circle",{cx:"130",cy:"7",r:"5.5",fill:"#57d9ff"}),(0,t.jsx)("path",{d:"M78 170 Q130 188 182 170 L174 189 Q130 199 86 189Z",fill:"#10181d"})]})}])},39624,e=>{"use strict";e.s(["f",0,function(e){var t;let i=document.createElement("canvas");i.width=1024,i.height=512;let r=i.getContext("2d");if(!r)return i;let o=(t="Moon"===e?0x12c74e0:0x130ba90,function(){let e=t+=0x6d2b79f5;return e=Math.imul(e^e>>>15,1|e),(((e^=e+Math.imul(e^e>>>7,61|e))^e>>>14)>>>0)/0x100000000}),s="Moon"===e,n=r.createLinearGradient(0,0,1024,512);if(s?(n.addColorStop(0,"#8e9290"),n.addColorStop(.45,"#b8bbb7"),n.addColorStop(.7,"#8b908e"),n.addColorStop(1,"#a5a8a3")):(n.addColorStop(0,"#9a4b32"),n.addColorStop(.38,"#c06a42"),n.addColorStop(.64,"#8f402d"),n.addColorStop(1,"#b15b39")),r.fillStyle=n,r.fillRect(0,0,1024,512),s)for(let e=0;e<12;e+=1){let e=1024*o(),t=40+432*o(),i=50+180*o(),s=24+90*o(),n=r.createRadialGradient(e,t,0,e,t,i);n.addColorStop(0,"rgba(48, 54, 55, .34)"),n.addColorStop(.7,"rgba(58, 64, 64, .18)"),n.addColorStop(1,"rgba(58, 64, 64, 0)"),r.save(),r.translate(e,t),r.scale(1,s/i),r.fillStyle=n,r.beginPath(),r.arc(0,0,i,0,2*Math.PI),r.fill(),r.restore()}else{let e=r.createLinearGradient(0,0,0,44);e.addColorStop(0,"rgba(238, 229, 215, .85)"),e.addColorStop(1,"rgba(238, 229, 215, 0)"),r.fillStyle=e,r.fillRect(0,0,1024,44);let t=r.createLinearGradient(0,512,0,480);t.addColorStop(0,"rgba(238, 229, 215, .72)"),t.addColorStop(1,"rgba(238, 229, 215, 0)"),r.fillStyle=t,r.fillRect(0,480,1024,32);for(let e=0;e<9;e+=1){let e=1024*o(),t=70+372*o();r.strokeStyle="rgba(74, 35, 27, .3)",r.lineWidth=1+3*o(),r.beginPath(),r.moveTo(e,t);for(let i=0;i<7;i+=1)r.lineTo(e+28*i+40*o(),t+(o()-.5)*44);r.stroke()}}let a=s?180:60;for(let e=0;e<a;e+=1){let e=1024*o(),t=24+464*o(),i=(s?1.2:2)+o()*(s?12:7),n=s?.28:.34;r.beginPath(),r.arc(e,t,i,0,2*Math.PI),r.fillStyle=`rgba(40, 38, 34, ${n*o()})`,r.fill(),r.beginPath(),r.arc(e-.25*i,t-.25*i,.82*i,0,2*Math.PI),r.strokeStyle=`rgba(246, 238, 219, ${.08+.11*o()})`,r.lineWidth=Math.max(.4,.12*i),r.stroke()}let l=r.getImageData(0,0,1024,512),d=l.data;for(let e=0;e<d.length;e+=4){let t=(o()-.5)*(s?13:10);d[e]=Math.max(0,Math.min(255,d[e]+t)),d[e+1]=Math.max(0,Math.min(255,d[e+1]+t)),d[e+2]=Math.max(0,Math.min(255,d[e+2]+t))}return r.putImageData(l,0,0),i}])}]);